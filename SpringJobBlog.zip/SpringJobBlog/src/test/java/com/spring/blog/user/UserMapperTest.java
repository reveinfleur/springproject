package com.spring.blog.user;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.spring.blog.command.UserVO;
import com.spring.blog.user.mapper.IUserMapper;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("file:src/main/webapp/WEB-INF/config/db-config.xml")
public class UserMapperTest {

	@Autowired
	private IUserMapper usermapper;
	
	/*
	@Test
	public void userJoin() throws Exception{
		UserVO user = new UserVO();
		
		user.setU_id("spring_test1");
		user.setU_pw("spring_test1");
		user.setU_pwAnswer("spring_test1");
		user.setU_nickname("spring_test1");
		user.setU_name("spring_test1");
		user.setU_email("spring_test1");
		user.setU_phone("spring_test1");
		user.setU_addrPost("spring_test1");
		user.setU_addrBasic("spring_test1");
		user.setU_addrDetail("spring_test1");

		
		usermapper.generalJoin(user);
	}
	*/
	
	@Test
	public void userIdChk() throws Exception{
		String id = "spring_test1";
		String id2 = "test1";
		System.out.println("첫번째 결과: " + usermapper.idCheck(id));
		System.out.println("두번째 결과: " + usermapper.idCheck(id2));
	}
	

	
}
















