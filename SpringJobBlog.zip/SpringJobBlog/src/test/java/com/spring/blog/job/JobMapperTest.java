package com.spring.blog.job;

import java.util.Date;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.spring.blog.command.JobVO;
import com.spring.blog.job.mapper.IJobMapper;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("file:src/main/webapp/WEB-INF/config/db-config.xml")
public class JobMapperTest {

	@Autowired
	private IJobMapper mapper;
	
//	@Test
//	public void getListTest() {
//		mapper.getList().forEach(vo -> System.out.println(vo));
//	}
	
//	@Test
//	public void registTest() {
//		JobVO vo = new JobVO();
//		vo.setJTitle("경력사원 모집");
//		vo.setJWriter("삼성");
//		vo.setJDetail("경력 프론트엔드 개발자 모집");
//		vo.setJSchedule();
//		vo.setJCareer("경력"); 
//		vo.setJJobtype("IT");
//		vo.setJCompanytype("대기업");
//		mapper.regist(vo);
//	}

}
