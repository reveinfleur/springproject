package com.spring.blog.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.spring.blog.command.NoticeVO;
import com.spring.blog.command.UserVO;
import com.spring.blog.notice.service.INoticeService;

@Controller
@RequestMapping("/board/notice")
public class NoticeController {
	
	private INoticeService service;
	
	
    @Autowired
	public NoticeController(INoticeService service) {
		this.service = service;
	}
    
    @ModelAttribute("session")
	public UserVO userSession(HttpSession session) {
		if(session.getAttribute("login")!=null){
		   UserVO vo = (UserVO) session.getAttribute("login");
		   return vo;   
		}
		return null;	
	}

	@GetMapping("/noticelist")
	public String noticeListView(Model model) {
		
		model.addAttribute("boardList", service.getList());
		
		return "/board/notice/noticelist";
		
	}
	

	@GetMapping("/noticedetail")
	public String noticeDetailView(@RequestParam int boardNo, Model model) {
		
		service.hitcount(boardNo);
		
		model.addAttribute("article", service.getContent(boardNo));
			
		return "/board/notice/noticedetail";
		
	}
	
	
	@GetMapping("/noticeregist")
	public String noticeRegistView() {
		
		return "/board/notice/noticeregist";
		
	}
	
	
	@PostMapping("/noticeregist")
	public String noticeRegist(NoticeVO vo, RedirectAttributes ra) {
		service.regist(vo);
		
		ra.addFlashAttribute("msg", "registok");
		
		return "redirect:/board/notice/noticelist";
		
	}
	
	
	@GetMapping("/noticeDelete")
	public String noticeDelete(@RequestParam int boardNo, RedirectAttributes ra) {
		service.delete(boardNo);
		
		ra.addFlashAttribute("msg", "deleteok");
		return "redirect:/board/notice/noticelist";
	}
	
	
	@GetMapping("/noticemodify")
	public String noticeModifyView(@RequestParam int boardNo, Model model) {
		model.addAttribute("article", service.getContent(boardNo));
		
		return "/board/notice/noticemodify";
	}
	
	
	@PostMapping("/noticemodify")
	public String nodiceModify(NoticeVO vo, RedirectAttributes ra) {
			
		service.update(vo);
		System.out.println("vo: " + vo);
		ra.addFlashAttribute("msg", "modifyok");
			
		return "redirect:/board/notice/noticelist";
	}
	
}
