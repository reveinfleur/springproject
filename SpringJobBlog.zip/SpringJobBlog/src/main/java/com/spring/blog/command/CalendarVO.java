package com.spring.blog.command;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class CalendarVO{
	
	private String year;
	private String month;
	private String day;
	private String schedule;
	private int jno;

}
