package com.spring.blog.interview.service;

import java.util.List;

import com.spring.blog.command.InterviewBoardVO;
import com.spring.blog.command.ResumeBoardVO;
import com.spring.blog.util.PageVO;

public interface IInterviewBoardService {
	
	
		//글 등록
		void write(InterviewBoardVO vo);
				
		//글 목록
		List<InterviewBoardVO> getList(PageVO vo);
				
		//총 게시물 수
		int getTotal(PageVO vo);
				
		//상세보기
		InterviewBoardVO getDetail(int rNo);
			
		//수정
		void update(InterviewBoardVO vo);

		//삭제
		void delete(InterviewBoardVO vo);
				
}
