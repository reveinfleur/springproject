package com.spring.blog.like.service;

import com.spring.blog.command.LikeVO;

public interface ILikeService {
	
	
	// 좋아요 수 확인
	int likeCount(LikeVO vo);

	// 좋아요 눌러져 있을때 변환
	void likeUpdate(LikeVO vo);

	// 좋아요 처음 눌렀을때
	void likeInsert(LikeVO vo);

	// 좋아요 현재 상태 
	int likeInfo(LikeVO vo);
	
	// 좋아요 한 유저정보
    int likeGetInfo(LikeVO vo);

}
