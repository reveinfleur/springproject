package com.spring.blog.notice.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.blog.notice.mapper.INoticeMapper;
import com.spring.blog.command.NoticeVO;

@Service
public class NoticeService implements INoticeService{
	
	private INoticeMapper mapper;
	
	@Autowired
	public NoticeService(INoticeMapper mapper) {
		this.mapper = mapper;
	}

	@Override
	public void regist(NoticeVO vo) {
		mapper.regist(vo);
		
	}

	@Override
	public List<NoticeVO> getList() {
		List<NoticeVO> list = mapper.getList();
		return list;
	}

	@Override
	public NoticeVO getContent(int b_no) {
		return mapper.getContent(b_no);
	}

	@Override
	public void delete(int b_no) {
		mapper.delete(b_no);
		
	}

	@Override
	public void update(NoticeVO vo) {
		mapper.update(vo);
		
	}

	@Override
	public void hitcount(int b_no) {
		mapper.hitcount(b_no);
		
	}

}
