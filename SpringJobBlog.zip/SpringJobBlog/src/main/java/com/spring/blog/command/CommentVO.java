package com.spring.blog.command;

import java.sql.Timestamp;

import lombok.Getter;
import lombok.Setter;

/*
CREATE TABLE comment_table(
    c_no NUMBER(10, 0), --댓글번호 (PK)
    s_no NUMBER(10, 0), -- studyboard 번호
    f_no NUMBER(10, 0), -- freeboard 번호
    i_no NUMBER(10, 0), -- interviewboard 번호
    j_no NUMBER(10, 0), -- jobboard 번호
    r_no NUMBER(10, 0), -- resumeboard 번호
    c_comment VARCHAR2(500), -- 내용
    c_writer VARCHAR2(50), -- 작성자 (fk)
    c_date DATE DEFAULT SYSDATE, --등록일 
    c_updatedate DATE DEFAULT NULL --댓글 수정일
);

ALTER TABLE comment_table 
ADD CONSTRAINT comment_table_pk PRIMARY KEY(c_no);

CREATE SEQUENCE s_no_seq
    START WITH 1
    INCREMENT BY 1
    MAXVALUE 1000
    NOCYCLE
    NOCACHE;

 */



@Getter
@Setter

public class CommentVO {
	
	private int cmtNo;
	private int stuNo;
	private int freeNo;
	private int interNo;
	private int resNo;
	private int jobNo;
	
	private String cmtComment;
	private String cmtWriter;
	private Timestamp cmtDate;
	private Timestamp cmtUpdatedate;
	

}
