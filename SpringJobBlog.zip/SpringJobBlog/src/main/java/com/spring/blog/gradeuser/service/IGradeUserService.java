package com.spring.blog.gradeuser.service;

import java.util.List;

import com.spring.blog.command.GradeUserVO;
import com.spring.blog.command.NoticeVO;
import com.spring.blog.command.UserVO;
import com.spring.blog.util.PageVO;


public interface IGradeUserService {
	
		void regist(GradeUserVO vo);
		
		List<GradeUserVO> getList(PageVO vo);
		
		int getTotal(PageVO vo);
		
		GradeUserVO getContent(int userNo);

		void delete(int userNo);

		void gradeApplyAccess(String userGrade, String userId);

		void gradeApplyCheck(int userNo);
		
	

}
