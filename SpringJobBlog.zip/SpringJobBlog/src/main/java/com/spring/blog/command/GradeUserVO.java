package com.spring.blog.command;

import java.sql.Timestamp;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/*
CREATE TABLE user_grade 
( 
    u_no     NUMBER(20) PRIMARY KEY,
    u_id       VARCHAR(20) NOT NULL,
    u_nickname     VARCHAR2(100) NOT NULL,
    u_title  VARCHAR2(100) NOT NULL,
    u_grade_regist_date date default SYSDATE, 
    u_grade_apply   VARCHAR2(30) NOT NULL,
    u_grade_apply_check   VARCHAR2(30),
    u_content  VARCHAR2(50) NOT NULL
);
*/

@Getter
@Setter
@ToString
public class GradeUserVO {
	private int userNo;
	private String userId;
	private String userNickName;
	private String userTitle;
	private String userGradeApply;
	private String userGradeCheck;
	private String userContent;
	private Timestamp userGradeRegistDate;
}
