package com.spring.blog.command;

import java.sql.Timestamp;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/*
자소서 게시판
CREATE TABLE resume_board(  -- 게시판 테이블
    r_no NUMBER(10, 0), --글번호
    r_title VARCHAR2(300) NOT NULL, --글제목
    r_writer VARCHAR2(50) NOT NULL, --작성자
    r_detail VARCHAR2(2000) NOT NULL, --글내용
    r_regdate DATE DEFAULT SYSDATE, -- 작성일
    r_updatedate DATE DEFAULT NULL, -- 수정일
    r_jobtype VARCHAR2(50) NULL, --직군
    r_result  VARCHAR2(50) NULL, --합/불
    r_count NUMBER DEFAULT 0,  --조회수
    r_likeCount NUMBER(10, 0) --좋아요 카운트
);

ALTER TABLE resume_board
ADD CONSTRAINT resume_board_pk PRIMARY KEY(r_no);

CREATE SEQUENCE r_no_seq --글번호 시퀀스
    START WITH 1
    INCREMENT BY 1
    MAXVALUE 10000
    NOCYCLE
    NOCACHE;
*/

@Setter
@Getter
@ToString
public class ResumeBoardVO {
	private int resNo;
	private String resTitle;
	private String resWriter;
	private String resDetail;
	private Timestamp resRegdate;
	private Timestamp resUpdatedate;
	private String resJobtype;
	private String resResult;
	private int resCount;
	private int resLikeCount;

	// 첨부파일
	private String fileRealName;
	private String fileName;
	private String uploadPath;

}
