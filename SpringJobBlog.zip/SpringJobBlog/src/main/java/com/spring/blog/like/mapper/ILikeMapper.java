package com.spring.blog.like.mapper;

import com.spring.blog.command.LikeVO;

public interface ILikeMapper {
	
	//좋아요 수 확인
	int likeCount(LikeVO vo);
	
	//좋아요 눌러져 있을때 변환 
	void likeUpdate(LikeVO vo);
	
	// 좋아요 처음 눌렀을때
	void likeInsert(LikeVO vo);
	
	// 좋아요 안한 유저정보 저장?
	int likeInfo(LikeVO vo);
	
	// 좋아요 한 유저정보
	int likeGetInfo(LikeVO vo);

}
