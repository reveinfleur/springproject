package com.spring.blog.controller;

import java.util.Random;

import javax.mail.Session;
import javax.mail.internet.MimeMessage;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;


import com.spring.blog.command.UserVO;
import com.spring.blog.user.service.IUserService;
import com.spring.blog.util.PasswordChangeVO;

@Controller
@RequestMapping(value = "/user")
public class UserController {

	private static final Logger logger = LoggerFactory.getLogger(UserController.class);

	@Autowired
	private IUserService userservice;
	
	@Autowired
	private JavaMailSender mailSender;


	@ModelAttribute("session")
	public UserVO userSessionInfo(HttpSession session) {
		if(session.getAttribute("login")!=null) {
			UserVO vo = (UserVO)session.getAttribute("login");
			return vo;
		}
		return null;
	}
	
	
	// 회원가입 선택 페이지 이동 요청
	@GetMapping("/userJoin")
	public void userJoin() {
		logger.info("회원가입 선택 페이지 진입");
	}

	
	// 개인 회원가입 페이지 이동 요청
	@GetMapping("/userJoinGeneral")
	public void userJoinGeneral() {
		logger.info("개인 회원가입 페이지 진입");
	}

	//개인 회원 가입 처리
	@PostMapping("/userJoinGeneral")
	public String generalJoin(UserVO user) {
		
		userservice.generalJoin(user);
		logger.info("개인 회원가입 성공!");
		return "redirect:../main";
		
	}
		

	// 기업 회원가입 페이지 이동 요청
	@GetMapping("/userJoinCompany")
	public void userJoinCompany() {
	}

	//기업 회원 가입 처리
	@PostMapping("/userJoinCompany")
	public String companyJoin(UserVO user) {
		
		userservice.companyJoin(user);
		logger.info("기업 회원가입 성공!");
		return "redirect:../main";
		
	}
	
	
	// 아이디 중복 검사
	@RequestMapping(value = "/userIdChk", method = RequestMethod.POST)
	@ResponseBody
	public String userIdChk(String u_id) throws Exception{
		
		logger.info("userIdChk() 진입");
		
		int result = userservice.idCheck(u_id);
		
		logger.info("결과값= " + result);
		
		if(result != 0) {
			return "fail"; // 중복아이디 O
		} else {
			return "sucess"; // 중복아이디 X
		}
	} // memberIdChkPOST() 종료	
	
	
	
    /* 이메일 인증 */
    @RequestMapping(value="/mailCheck", method=RequestMethod.GET)
    @ResponseBody
    public String mailCheckGET(String email) throws Exception{
        
        /* 뷰(View)로부터 넘어온 데이터 확인 */
        logger.info("이메일 데이터 전송 확인");
        logger.info("인증번호 : " + email);
        
        /* 인증번호(난수) 생성 */
        Random random = new Random();
        int checkNum = random.nextInt(888888) + 111111;
        logger.info("인증번호 " + checkNum);        
        
        
        /* 이메일 보내기 */
        String setFrom = "meohaejyo@gmail.com";
        String toMail = email;
        String title = "회원가입 인증 이메일 입니다.";
        String content = 
                "잡담드림을 방문해주셔서 감사합니다." +
                "<br><br>" + 
                "인증 번호는 " + checkNum + "입니다." + 
                "<br>" + 
                "해당 인증번호를 인증번호 확인란에 기입하여 주세요.";
        

        try {
            
            MimeMessage message = mailSender.createMimeMessage();
            MimeMessageHelper helper = new MimeMessageHelper(message, true, "utf-8");
            helper.setFrom(setFrom);
            helper.setTo(toMail);
            helper.setSubject(title);
            helper.setText(content,true);
            mailSender.send(message);
            
        }catch(Exception e) {
            e.printStackTrace();
        }
        
        String num = Integer.toString(checkNum);
        
        return num;
    }
 
    
	// 로그인 페이지 이동 요청
	@GetMapping("/userLogin")
	public void userLogin() {
		logger.info("로그인 페이지 진입");
	}
    
	//로그인 처리
	@PostMapping("/login")
	public String login(HttpServletRequest request, String userId, String userPw, Model model
					    , RedirectAttributes ra) {
		
		//HttpSession session = request.getSession();
		UserVO lvo = userservice.login(userId, userPw);
		
		System.out.println("param: " + userId + ", " + userPw);
		
		System.out.println("lvo: " + lvo);
		
		model.addAttribute("user", lvo);
				
//		if(lvo != null) { //로그인 성공
//			model.addAttribute("lvo", lvo);
//			session.setAttribute("user", lvo);
//			System.out.println("로그인 model : " + model);
//			System.out.println("로그인 user : " + session);
//			System.out.println("로그인 lvo : " + lvo);
//			return "redirect:/main";
//		} else {
//			int result = 0;
//			ra.addFlashAttribute("result", result);
//		}
		return "/user/userLogin";
		
		
	}
    
    /* 메인페이지 로그아웃 */
    @RequestMapping(value="logout", method=RequestMethod.GET)
    public String logoutMainGET(HttpServletRequest request) throws Exception{
        
        logger.info("logoutMainGET메서드 진입");
        
        HttpSession session = request.getSession();
        session.invalidate();
        
        return "redirect:../main";  
    }

    
    @GetMapping("/userMypage")
    public String userMypage(HttpSession session, Model model) {
    	
//    	String u_id = ((UserVO) session.getAttribute("login.do")).getU_id();
//    	UserVO lvo = (UserVO) session.getAttribute("user");
    	UserVO lvo = (UserVO) session.getAttribute("login");
    	System.out.println("lvo의 값: " + lvo);
    	String userId = lvo.getUserId();
    	System.out.println("userId의 값:" + userId);
    	System.out.println("테스트진입");
    	
		UserVO userInfo = userservice.getInfo(userId);
		model.addAttribute("userInfo", userInfo);
    		
    	return "/user/userMypage";
    }
    
	//수정 로직
	@PostMapping("/userUpdate")
	public String userUpdate(UserVO lvo, RedirectAttributes ra) {
		System.out.println("param: " + lvo);
		userservice.updateUser(lvo);
		int success = 1;
		ra.addFlashAttribute("success", success);
		return "redirect:/user/userMypage";
	}
	

	// 아이디 비밀번호 찾기 페이지 이동 요청
	@GetMapping("/idpwSearch")
	public void idpwSearch() {
	}


	// 회원 탈퇴 페이지 이동 요청
	@GetMapping("/userUnregister")
	public void userUnregister() {
		
	}
	
	@PostMapping("/deleteUser") 
	public String deleteUser(UserVO user, RedirectAttributes ra, HttpSession session) {
		System.out.println("user: " + user);
		int result = userservice.checkPw(user);
		System.out.println("result: " + result);
		if(result == 1) {
			userservice.deleteUser(user);
			session.invalidate();
			int success = 1;
			ra.addFlashAttribute("success", success);
			return "redirect:../main";
		} else {
			int fail = 0;
			System.out.println("fail: " + fail);
			ra.addFlashAttribute("fail", fail);
			return "redirect:/user/userUnregister";
		}	
	}
	
	@PostMapping("/changePw")
	public String userPwChange(PasswordChangeVO vo, RedirectAttributes ra, HttpServletRequest request) {
		System.out.println("비밀번호변경"+vo);
		int result = userservice.checkPw2(vo);
		System.out.println(result);
		if(result==1) {
			userservice.changeUserPassword(vo);
	        HttpSession session = request.getSession();
	        session.invalidate();
			int success1 = 1;
			ra.addFlashAttribute("success1", success1);
			return "redirect:../user/userLogin";
		}
		else {
			int fail = 0;
			ra.addFlashAttribute("fail", fail);
			return "redirect:/user/userMypage";
		}
		
		
	}
	
}
