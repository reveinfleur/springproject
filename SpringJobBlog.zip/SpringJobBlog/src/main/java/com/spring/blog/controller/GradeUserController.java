package com.spring.blog.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.spring.blog.gradeuser.service.IGradeUserService;
import com.spring.blog.user.service.IUserService;
import com.spring.blog.command.GradeUserVO;
import com.spring.blog.command.UserVO;
import com.spring.blog.util.PageCreator;
import com.spring.blog.util.PageVO;

import lombok.extern.slf4j.Slf4j;


@Controller
@RequestMapping("/user")
@Slf4j
public class GradeUserController {
	
	private IGradeUserService service;
	
	@Autowired
	private IUserService userService;
				
	@Autowired
	public GradeUserController(IGradeUserService service) {
		this.service = service;
	}
		
	@ModelAttribute("session")
	public UserVO userSession(HttpSession session) {
		if(session.getAttribute("login")!=null)
		{
		   UserVO vo = (UserVO) session.getAttribute("login");
		   return vo;	   
		}
		return null;	
	}
	
	@GetMapping("/grade")
	public String gradeView(Model model, PageVO vo, HttpSession session) {
		UserVO vv2 = (UserVO)session.getAttribute("login");
		System.out.println(vv2.getUserId());
		int boardCount = userService.getBoardCount(vv2.getUserId());
		model.addAttribute("userboardhit", boardCount);
			
		System.out.println(boardCount);
			
		PageCreator pc = new PageCreator();
		pc.setPaging(vo);
		pc.setArticleTotalCount(service.getTotal(vo));
		
		UserVO vo2 = (UserVO)session.getAttribute("user");
		model.addAttribute("session", vo2);			
		model.addAttribute("pc", pc);
		model.addAttribute("gradeList", service.getList(vo));
		return "/user/grade";
	}
		
	@PostMapping("/grade")
	public String gradeApply(GradeUserVO vo, RedirectAttributes ra, HttpSession session) {
		UserVO vv2 = (UserVO)session.getAttribute("login");
		service.regist(vo);	
		userService.boardCountAdd(vv2.getUserId());
		
		ra.addFlashAttribute("msg", "registok");	
		return "redirect:/user/grade";
	}
		
	@GetMapping("/gradeDetail")
	public String gradeDetailView(@RequestParam int userNo, Model model, HttpSession session) {
		
		model.addAttribute("article", service.getContent(userNo));
		model.addAttribute("userNo", userNo);
					
		return "/user/gradeDetail";
	}
	
	@PostMapping("/gradeApply")
	public String gradeDetailAccess(RedirectAttributes ra, @RequestParam String userId, @RequestParam String userGrade, @RequestParam int userNo) {
		log.info(userGrade);
		log.info(userId);
		UserVO vo= new UserVO();
		vo.setUserId(userId);
		vo.setUserGrade(userGrade);
		service.gradeApplyCheck(userNo);
		userService.userGradeUpdate(vo);
		ra.addFlashAttribute("msg", "gradeapplyok");
		
		
		return "redirect:/user/grade";
	}
	
	@GetMapping("/gradeDelete")
	public String gradeDelete(@RequestParam int userNo, RedirectAttributes ra) {
		service.delete(userNo);
		
		ra.addFlashAttribute("msg", "deleteok");
		return "redirect:/user/grade";
		
	}

}
