package com.spring.blog.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.spring.blog.command.LikeVO;
import com.spring.blog.like.service.ILikeService;

@RestController
@RequestMapping("/like")
public class LikeController {
	
	@Autowired
	private ILikeService service;
	
	@GetMapping("/likeUpdate")
	public Map<String,String> likeUpdate(@RequestBody LikeVO vo) {
		Map<String,String> map = new HashMap<String, String>();
		
		try {
			service.likeUpdate(vo);
			map.put("result", "success");
			System.out.println("업데이트 요청 성공");
		} catch(Exception e) {
			e.printStackTrace();
			map.put("result", "fail");
			System.out.println("업데이트 요청 실패");
		}
		return map;
	}
	
}
