package com.spring.blog.user.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.spring.blog.command.UserVO;
import com.spring.blog.user.mapper.IUserMapper;
import com.spring.blog.util.PasswordChangeVO;


@Service
public class UserService implements IUserService{
	
	@Autowired
	private IUserMapper mapper;


	//유저 등업
	@Override
	public void userGradeUpdate(UserVO vo) {
		mapper.userGradeUpdate(vo);
		
	}
	
	//개인 회원가입
	@Override
	public void generalJoin(UserVO user) {
		
		mapper.generalJoin(user);
		
	}
	
	//기업 회원가입
	@Override
	public void companyJoin(UserVO user) {
		
		mapper.companyJoin(user);
		
	}
	
	//아이디 중복 검사
	@Override
	public int idCheck(String userId){
		
		return mapper.idCheck(userId);
		
	}
	
	//로그인 검사
	@Override
	public UserVO login(String userId, String userPw) {
		return mapper.login(userId, userPw);
	}
    
    //마이페이지
	@Override
	public UserVO getInfo(String userId) {
		return mapper.getInfo(userId);
	}
	
	//회원정보 수정
	@Override
	public void updateUser(UserVO user) {
		mapper.updateUser(user);
	}
	
	//회원정보 수정
	@Override
	public void pwUser(UserVO user) {
		mapper.pwUser(user);
	}

	//유저 삭제
	@Override
	public void deleteUser(UserVO user) {
		mapper.deleteUser(user);
	}

	//비밀번호 체크
	@Override
	public int checkPw(UserVO user) {
		return mapper.checkPw(user);
	}

    
	//비밀번호 변경 체크2
	@Override
	public int checkPw2(PasswordChangeVO vo) {
		
		return mapper.checkPw2(vo);
	}

	//비밀번호 변경
	@Override
	public void changeUserPassword(PasswordChangeVO vo) {
		mapper.changeUserPassword(vo);
		
	}

	//게시물 갯수 가져오기
	@Override
	public int getBoardCount(String userId) {
		
		return mapper.getBoardCount(userId);
	}

	//게시물 카운트 업데이트
	@Override
	public void boardCountAdd(String userId) {
	
		mapper.boardCountAdd(userId);
	}
	

	
	
	
}
