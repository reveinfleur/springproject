package com.spring.blog.util;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class PageVO {

	private int pageNum;
	private int countPerPage;

	//검색
	private String keyword;
	private String condition;
	private String condition1;
	private String condition2;

	public PageVO() {
		this.pageNum = 1;
		this.countPerPage = 8;
	}
}
