package com.spring.blog.gradeuser.mapper;

import java.util.List;

import com.spring.blog.command.GradeUserVO;


import com.spring.blog.util.PageVO;


public interface IGradeUserMapper {
	
		void regist(GradeUserVO vo);
		
		List<GradeUserVO> getList(PageVO vo);
		
		int getTotal(PageVO vo);
					
		GradeUserVO getContent(int userNo);
					
		void delete(int userNo);
		
		void update(GradeUserVO vo);
		
		void gradeApplyAccess(String userGrade, String userId);
		
		void gradeApplyCheck(int userNo);

}
