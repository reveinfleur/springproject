package com.spring.blog.notice.mapper;

import java.util.List;

import com.spring.blog.command.NoticeVO;

public interface INoticeMapper {
	
	void regist(NoticeVO vo);
	
	List<NoticeVO> getList();
	
	NoticeVO getContent(int b_no);
	
	void delete(int b_no);
	
	void update(NoticeVO vo);
	
	void hitcount(int b_no);

}
