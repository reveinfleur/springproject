package com.spring.blog.util.interceptor;

import java.io.PrintWriter; 

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import com.spring.blog.command.UserVO;


public class BoardAuthHandler extends HandlerInterceptorAdapter {
	
	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
			throws Exception {
		
		System.out.println("게시판 권한 인터셉터 발동!");
		
		String resWriter = request.getParameter("resWriter");
		String interWriter = request.getParameter("interWriter");
		String stuWriter = request.getParameter("stuWriter");
		String freeWriter = request.getParameter("freeWriter");
		String jobWriter = request.getParameter("jobWriter");
		
		HttpSession session = request.getSession();
		UserVO vo = (UserVO) session.getAttribute("login");
		
		
		System.out.println("화면에서 넘어오는 값: " + resWriter);
		System.out.println("세션에 저장된 값: " + vo);
		System.out.println("화면에서 넘어오는 값: " + interWriter);
		System.out.println("세션에 저장된 값: " + vo);
		System.out.println("화면에서 넘어오는 값: " + stuWriter);
		System.out.println("세션에 저장된 값: " + vo);
		System.out.println("화면에서 넘어오는 값: " + freeWriter);
		System.out.println("세션에 저장된 값: " + vo);
		System.out.println("화면에서 넘어오는 값: " + jobWriter);
		System.out.println("세션에 저장된 값: " + vo);
		
		if(vo != null) {
			if(resWriter.equals(vo.getUserNickname())) {
				return true; //컨트롤러로 요청의 진입을 허용
			} if(interWriter.equals(vo.getUserId())) {
				return true; //컨트롤러로 요청의 진입을 허용 
			} else if(stuWriter.equals(vo.getUserId())) {
				return true; //컨트롤러로 요청의 진입을 허용
			} else if(freeWriter.equals(vo.getUserId())) {
				return true; //컨트롤러로 요청의 진입을 허용
			} else if(jobWriter.equals(vo.getUserNickname())) {
				return true; //컨트롤러로 요청의 진입을 허용
			} else {
				return false;
			}
		} else {
			response.setContentType("text/html; charset=utf-8");
			PrintWriter out = response.getWriter();
			
			out.print("<script> \r\n");
			out.print("alert('권한이 없습니다.'); \r\n");
			out.print("history.back()");
			out.print("</script>");
			
			out.flush();
			
			return false;
			
		}
		
	}
	
}

