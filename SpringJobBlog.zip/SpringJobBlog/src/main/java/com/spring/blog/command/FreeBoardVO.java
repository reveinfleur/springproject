package com.spring.blog.command;

import java.sql.Timestamp;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/* 
-- 자유게시판
CREATE TABLE free_board( 
    f_no NUMBER(10, 0), --글번호 (pk)
    f_title VARCHAR2(300) NOT NULL, --글제목
    f_writer VARCHAR2(50) NOT NULL, --작성자 fk (닉네임)
    f_detail VARCHAR2(2000) NOT NULL, --글내용
    f_regdate DATE DEFAULT SYSDATE, -- 작성일
    f_updatedate DATE DEFAULT NULL, -- 수정일
    f_subject VARCHAR2(50), -- 주제 
    f_count NUMBER DEFAULT 0,  -- 조회수
    f_likeCount NUMBER(10, 0) -- 좋아요 카운트
);

ALTER TABLE free_board
ADD CONSTRAINT free_board_pk PRIMARY KEY(f_no);

CREATE SEQUENCE f_no_seq --글번호 시퀀스
    START WITH 1
    INCREMENT BY 1
    MAXVALUE 10000
    NOCYCLE
    NOCACHE;
 */

@Setter
@Getter
@ToString
public class FreeBoardVO {

	private int freeNo;
	private String freeTitle;
	private String freeWriter;
	private String freeDetail;
	private Timestamp freeRegdate;
	private Timestamp freeUpdatedate;
	private String freeSubject;
	private int freeCount;
	private int freeLikeCount;
}
