package com.spring.blog.controller;

import java.io.File;
import java.io.IOException;
import java.net.URLEncoder;
import java.util.UUID;

import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.io.FilenameUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.spring.blog.command.ResumeBoardVO;
import com.spring.blog.command.UserVO;
import com.spring.blog.resume.service.IResumeBoardService;
import com.spring.blog.user.service.IUserService;
import com.spring.blog.util.PageCreator;
import com.spring.blog.util.PageVO;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Controller
@RequestMapping("/board/resume/")
public class ResumeBoardController {

	
	@Autowired
	private IResumeBoardService service;
	
	@Autowired
	private IUserService uservice;

	//목록 화면
	@GetMapping("/resumeList")
	public String resumeList(PageVO vo, Model model) {
		
		PageCreator pc = new PageCreator();
		pc.setPaging(vo);
		pc.setArticleTotalCount(service.getTotal(vo));
		
		model.addAttribute("boardList", service.getList(vo));
		model.addAttribute("pc", pc);
			
		return "board/resume/resumeList";
	}
	
	//글쓰기 화면 처리
	@GetMapping("/resumeWrite")
	public void resumeWrite() {}

	//글 등록 처리
	@PostMapping("/resumeRegist")
	public String resumeRegist(ResumeBoardVO vo, RedirectAttributes ra, @RequestParam("file") MultipartFile file,  HttpSession session) {
			
		  UserVO user = (UserVO) session.getAttribute("login");
		
		  String fileName = null;
	      String fileRealName = null;
	      String uploadPath = null;
	      
	      if(!file.isEmpty()) {
	         fileRealName = file.getOriginalFilename();
	         UUID uuid = UUID.randomUUID();
	         String uuids = uuid.toString().replaceAll("-", "");
	         String fileExtension = FilenameUtils.getExtension(fileRealName);
	         uploadPath = "C:\\Users\\JyJung\\Desktop\\upload";
	         
	         System.out.println("저장할 폴더: " + uploadPath);
	         System.out.println("실제 파일명: " + fileRealName);
	         System.out.println("확장자: " + fileExtension);
	         System.out.println("uuid: " + uuids);
	         
	         fileName = uuids + "." + fileExtension;
	         System.out.println("변경해서 저장할 파일명: " + fileName);
	         
	         try {
	            file.transferTo(new File(uploadPath + "\\" + fileName));
	         } catch (Exception e) {
	            e.printStackTrace();
	         }
	      }
	         
	      vo.setFileName(fileName);
	      vo.setFileRealName(fileRealName);
	      vo.setUploadPath(uploadPath);
		
		service.write(vo);
		uservice.boardCountAdd(user.getUserId());
		
		ra.addFlashAttribute("msg", "정상 등록 처리되었습니다.");
		
		return "redirect:/board/resume/resumeList"; 		
		
	}
	
	//글 상세보기 처리
	@GetMapping("/resumeDetail")
	public void resumeDetail(@RequestParam int resNo, Model model, 
						   @ModelAttribute("p") PageVO vo) {
		model.addAttribute("article", service.getDetail(resNo));
	}

	//파일 다운로드 처리
	@PostMapping("/resumeDownload")
	public void resumeDownload(ResumeBoardVO vo, RedirectAttributes ra,
								@RequestParam String fileN, HttpServletResponse response) {
		String fileName = fileN;
		//String fileRealName = fileRN;

		try {
			byte fileByte[] = org.apache.commons.io.FileUtils.readFileToByteArray(new File("C:\\Users\\JyJung\\Desktop\\upload\\"+fileName));
			System.out.println("다운로드 성공!");
			
			response.setContentType("application/octet-stream");
			response.setContentLength(fileByte.length);
			response.setHeader("Content-Disposition",  "attachment; fileName=\""+URLEncoder.encode(fileName, "UTF-8")+"\";");
			response.getOutputStream().write(fileByte);
			response.getOutputStream().flush();
			response.getOutputStream().close();
			
			vo.setFileRealName(fileName);
		} catch (IOException e) {
			System.out.println("에러발생");
			e.printStackTrace();
		}
		
		service.download(vo);
		
	}
	
	//글 수정 페이지 이동
	@GetMapping("/resumeModify")
	public void resumeModify(@RequestParam int resNo, Model model) {
		model.addAttribute("article", service.getDetail(resNo));
	}
	
	//글 수정 처리
	@PostMapping("/resumeUpdate")
	public String resumeUpdate(ResumeBoardVO vo, RedirectAttributes ra, @RequestParam("file") MultipartFile file,
			@RequestParam String fileRN, @RequestParam String fileN, @RequestParam String upload) {
		
		String fileName = fileN;
		String fileRealName = fileRN;
		String uploadPath = upload;	
		
		if(!file.isEmpty()) {
			fileRealName = file.getOriginalFilename();
			UUID uuid = UUID.randomUUID();
			String uuids = uuid.toString().replaceAll("-", "");
			String fileExtension = FilenameUtils.getExtension(fileRealName);
			uploadPath = "C:\\Users\\JyJung\\Desktop\\upload";
			
			System.out.println("저장할 폴더: " + uploadPath);
			System.out.println("실제 파일명: " + fileRealName);
			System.out.println("확장자: " + fileExtension);
			System.out.println("uuid: " + uuids);
			
			fileName = uuids + "." + fileExtension;
			System.out.println("변경해서 저장할 파일명: " + fileName);
			
			try {
				String fileLoca = uploadPath + "\\" + fileName;
				file.transferTo(new File(fileLoca));
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
			
		vo.setFileName(fileName);
		vo.setFileRealName(fileRealName);
		vo.setUploadPath(uploadPath);
		service.update(vo);
		ra.addFlashAttribute("msg", "정상적으로 수정되었습니다.");
		
		return "redirect:/board/resume/resumeDetail?resNo=" + vo.getResNo();
	}
	
	@PostMapping("/resumeDelete")
	public String resumeDelete(ResumeBoardVO vo, RedirectAttributes ra) {
		service.delete(vo);
		System.out.println("게시글 삭제 요청");
		ra.addFlashAttribute("msg", "게시글이 정상 삭제되었습니다.");
		
		return "redirect:/board/resume/resumeList";
	}
	
	

}


