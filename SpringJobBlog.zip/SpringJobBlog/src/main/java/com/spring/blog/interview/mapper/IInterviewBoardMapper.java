package com.spring.blog.interview.mapper;

import java.util.List;

import com.spring.blog.command.InterviewBoardVO;
import com.spring.blog.command.ResumeBoardVO;
import com.spring.blog.util.PageVO;

public interface IInterviewBoardMapper {

		//글 등록
		void write(InterviewBoardVO vo);
			
		//글 목록
		List<InterviewBoardVO> getList(PageVO vo);
			
		//총 게시물 수
		int getTotal(PageVO vo);
		
		//조회수 상승 처리
		void updateViewCnt(int interNo);

		//상세보기
		InterviewBoardVO getDetail(int interNo);
			
		//수정
		void update(InterviewBoardVO vo);
		
		//삭제
		void delete(InterviewBoardVO vo);
									
}
