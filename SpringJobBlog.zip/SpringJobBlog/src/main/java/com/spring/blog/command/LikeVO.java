package com.spring.blog.command;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/*
 CREATE TABLE lkie_table(
	     like_no NUMBER(10, 0), --좋아요 번호 (PK)
	     s_no NUMBER(10, 0), -- 좋아요 게시물 번호 
	     u_id VARCHAR2(50), -- 좋아요 유저 아이디
	     like_check NUMBER(10, 0) DEFAULT 0 NULL ==좋아요 체크확인
	);
*/

@Getter
@Setter
@ToString
public class LikeVO {
	
	private int likeNo;
	private int stuNo;
	private String userId;
	private int likeCheck;

}
