package com.spring.blog.interview.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.blog.command.InterviewBoardVO;
import com.spring.blog.command.ResumeBoardVO;
import com.spring.blog.interview.mapper.IInterviewBoardMapper;
import com.spring.blog.util.PageVO;

@Service
public class InterviewBoardService implements IInterviewBoardService {

	@Autowired
	private IInterviewBoardMapper mapper;
	
	@Override
	public void write(InterviewBoardVO vo) {
		mapper.write(vo);
	}

	@Override
	public List<InterviewBoardVO> getList(PageVO vo) {
		List<InterviewBoardVO> list = mapper.getList(vo);

		return list;
	}

	@Override
	public int getTotal(PageVO vo) {
		return mapper.getTotal(vo);
	}

	@Override
	public InterviewBoardVO getDetail(int interNo) {
		mapper.updateViewCnt(interNo);
		return mapper.getDetail(interNo);	
	}

	@Override
	public void update(InterviewBoardVO vo) {
		mapper.update(vo);
	}

	@Override
	public void delete(InterviewBoardVO vo) {
		mapper.delete(vo);
	}

	
}
