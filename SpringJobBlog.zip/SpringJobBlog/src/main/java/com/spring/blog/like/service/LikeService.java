package com.spring.blog.like.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.blog.command.LikeVO;
import com.spring.blog.like.mapper.ILikeMapper;

@Service
public class LikeService implements ILikeService {
	
	
	@Autowired
	private ILikeMapper mapper;

	@Override
	public int likeCount(LikeVO vo) {
		return mapper.likeCount(vo);
	}

	@Override
	public void likeUpdate(LikeVO vo) {
		mapper.likeUpdate(vo);
	}

	@Override
	public void likeInsert(LikeVO vo) {
		mapper.likeInsert(vo);
	}


	@Override
	public int likeInfo(LikeVO vo) {
		return mapper.likeInfo(vo);
	}

	@Override
	public int likeGetInfo(LikeVO vo) {
		
		return mapper.likeGetInfo(vo);
	}

}
